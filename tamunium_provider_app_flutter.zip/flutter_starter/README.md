# TAMUNIUM Provider App — Flutter Starter

Covers: Auth (email/password) -> Home (availability toggle + summary) ->
Available Jobs (accept/reject, realtime) -> My Jobs (Active/History tabs) ->
Job Detail (start/complete flow).

## Setup

1. Unzip into a fresh Flutter project, or copy `lib/` and `pubspec.yaml`
   into an existing one (`flutter create tamunium_provider_app` first if
   starting fresh, then overwrite `lib/` and `pubspec.yaml`).
2. `flutter pub get`
3. Run with your real Supabase keys:

```
flutter run --dart-define=SUPABASE_URL=https://uzjbduranfsenrmitivp.supabase.co --dart-define=SUPABASE_ANON_KEY=your_anon_key
```

4. Log in with one of the 6 seeded accounts (e.g. `chidi@example.com`) and
   the password you set when creating that user in
   Authentication -> Users.

## How it maps to the backend

- **Auth**: `AuthService` wraps `supabase.auth.signInWithPassword`. Swap
  for `signInWithOtp(phone: ...)` later for phone-first onboarding —
  nothing downstream needs to change since everything else keys off
  `auth.uid()`.
- **currentProviderProvider**: looks up the `providers` row where
  `user_id = auth.uid()`. RLS's `providers_select` already allows any
  authenticated user to read this, so no extra policy work needed.
- **myJobsStreamProvider**: one realtime subscription on `jobs` filtered
  to `assigned_provider_id = <this provider>`. Screens (`Available`,
  `Active`, `History`) all derive from this single stream by filtering on
  `status` client-side, so there's only one open realtime channel instead
  of three.
- **Accept/Reject/Start/Complete**: all go through `JobsRepository`,
  which writes only the fields RLS's `jobs_update` policy allows a
  provider to touch (status, timestamps, notes) — it deliberately never
  writes `rate_amount` or `assigned_provider_id`, matching the `WITH
  CHECK` clause on that policy.

## Known gaps to fill in next

- No push notifications yet for new job offers (currently relies on the
  realtime stream while the app is open).
- No photo upload on job completion (schema has `photos` conceptually via
  a future `job_photos` table or a `photos` JSONB column — not yet in the
  schema you ran).
- No earnings screen yet — `provider_earnings` table is ready on the
  backend, just needs a repository + screen following the same pattern
  as `JobsRepository`.
